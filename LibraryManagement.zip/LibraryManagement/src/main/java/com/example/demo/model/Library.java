package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Library {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String bookname;
	private String authorname;
	private String bookcategory;
	private int edition;
	private double price;
	
	public Library()
	{
		
	}

	public Library(int id, String bookname, String authorname, String bookcategory, int edition, double price) {
		super();
		this.id = id;
		this.bookname = bookname;
		this.authorname = authorname;
		this.bookcategory = bookcategory;
		this.edition = edition;
		this.price = price;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBookname() {
		return bookname;
	}

	public void setBookname(String bookname) {
		this.bookname = bookname;
	}

	public String getAuthorname() {
		return authorname;
	}

	public void setAuthorname(String authorname) {
		this.authorname = authorname;
	}

	public String getBookcategory() {
		return bookcategory;
	}

	public void setBookcategory(String bookcategory) {
		this.bookcategory = bookcategory;
	}

	public int getEdition() {
		return edition;
	}

	public void setEdition(int edition) {
		this.edition = edition;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Library [id=" + id + ", bookname=" + bookname + ", authorname=" + authorname + ", bookcategory="
				+ bookcategory + ", edition=" + edition + ", price=" + price + "]";
	}

}